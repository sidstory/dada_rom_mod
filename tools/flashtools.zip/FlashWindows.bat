@echo off
title ��ˢ�ű� [����ѡ�д���,����ס���Ҽ���س��ָ�]
echo.������ ^<waiting for any device^> ������Ѱ������!
bin\Windows\fastboot getvar product 2>&1 | findstr /r /c:"^product: *houji" || echo.��ƥ����豸!
bin\Windows\fastboot getvar product 2>&1 | findstr /r /c:"^product: *houji" || exit /B 1
:MENU
if not exist bin\Windows (
   echo.
   echo.δ��ѹ! ����ȫ��ѹ!
   echo.
   pause
   exit
)
cls

if exist super.zst (
   echo.����ת�� super.zst Ϊ super.img, ���Ժ�...
   bin\Windows\zstd.exe --rm -d super.zst -o super.img
   if "%ERRORLEVEL%" neq "0" (
      echo.ת��ʧ�ܣ�
      pause
      exit
   )
)
cls

echo.
set /p KSU="�Ƿ���Ҫ KernelSU ? (y/n) "
echo.

rem
if /i "%KSU%" equ "y" (
   echo.����ˢ�� KernelSU...
   bin\Windows\fastboot flash init_boot "firmware-update/init_boot-kernelsu.img"
   echo.
   echo.����ˢ����������...
)
if /i "%KSU%" equ "n" (
   echo.����ˢ��...
   bin\Windows\fastboot flash init_boot "firmware-update/init_boot.img"
)

bin\Windows\fastboot flash abl "firmware-update/abl.img" 
bin\Windows\fastboot flash aop "firmware-update/aop.img" 
bin\Windows\fastboot flash aop_config "firmware-update/aop_config.img"
bin\Windows\fastboot flash bluetooth "firmware-update/bluetooth.img"
bin\Windows\fastboot flash boot "firmware-update/boot.img"
bin\Windows\fastboot flash cpucp "firmware-update/cpucp.img"
bin\Windows\fastboot flash cpucp_dtb "firmware-update/cpucp_dtb.img"
bin\Windows\fastboot flash devcfg "firmware-update/devcfg.img"
bin\Windows\fastboot flash dsp "firmware-update/dsp.img"
bin\Windows\fastboot flash dtbo "firmware-update/dtbo.img"
bin\Windows\fastboot flash featenabler "firmware-update/featenabler.img"
bin\Windows\fastboot flash hyp "firmware-update/hyp.img"
bin\Windows\fastboot flash imagefv "firmware-update/imagefv.img"
bin\Windows\fastboot flash keymaster "firmware-update/keymaster.img"
bin\Windows\fastboot flash modem "firmware-update/modem.img"
bin\Windows\fastboot flash modemfirmware "firmware-update/modemfirmware.img"
bin\Windows\fastboot flash multiimgqti "firmware-update/multiimgqti.img"
bin\Windows\fastboot flash qupfw "firmware-update/qupfw.img"
bin\Windows\fastboot flash recovery "firmware-update/recovery.img"
bin\Windows\fastboot flash shrm "firmware-update/shrm.img"
bin\Windows\fastboot flash spuservice "firmware-update/spuservice.img"
bin\Windows\fastboot flash tz "firmware-update/tz.img"
bin\Windows\fastboot flash uefi "firmware-update/uefi.img"
bin\Windows\fastboot flash uefisecapp "firmware-update/uefisecapp.img"
bin\Windows\fastboot flash vbmeta "firmware-update/vbmeta.img"
bin\Windows\fastboot flash vbmeta_system "firmware-update/vbmeta_system.img"
bin\Windows\fastboot flash vendor_boot "firmware-update/vendor_boot.img"
bin\Windows\fastboot flash vm-bootsys "firmware-update/vm-bootsys.img"
bin\Windows\fastboot flash xbl "firmware-update/xbl.img"
bin\Windows\fastboot flash xbl_config "firmware-update/xbl_config.img"
bin\Windows\fastboot flash xbl_ramdump "firmware-update/xbl_ramdump.img"
if exist super.img bin\Windows\fastboot flash super super.img
echo.ˢ�� super.img ���ܻῨһ���, �����ĵȴ�!

bin\Windows\fastboot reboot
pause